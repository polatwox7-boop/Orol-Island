package uz.orol.island

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.TextUtils
import android.util.TypedValue
import android.view.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlinx.coroutines.*

class IslandService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var rootContainer: FrameLayout
    private lateinit var pillCard: LinearLayout
    private lateinit var orbView: OrbView
    private lateinit var waveView: IconView
    private lateinit var textColumn: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var collapseJob: Job? = null
    private var isExpanded = false

    private val pillBg = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(Color.parseColor("#F5050507"))
        setStroke(2, Color.parseColor("#33FFFFFF"))
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundSafely()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildIslandView()
        observeBus()
    }

    private fun startForegroundSafely() {
        val channelId = "orol_island_channel"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Orol Dynamic Island",
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Orol Island faol")
            .setContentText("iOS Dynamic Island interfeysi ishlamoqda")
            .setSmallIcon(R.drawable.ic_island_notif)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                101,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(101, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildIslandView() {
        rootContainer = FrameLayout(this)

        pillCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pillBg
            elevation = dp(14).toFloat()
            clipToOutline = true
        }

        orbView = OrbView(this)
        waveView = IconView(this)

        textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(10), 0, dp(10), 0)
        }

        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            paint.isFakeBoldText = true
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = "Orol Island"
        }

        subtitleView = TextView(this).apply {
            setTextColor(Color.parseColor("#B3FFFFFF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            text = "iOS Dynamic Island tayyor"
        }

        textColumn.addView(titleView)
        textColumn.addView(subtitleView)

        val orbSize = dp(24)
        pillCard.addView(orbView, LinearLayout.LayoutParams(orbSize, orbSize))
        pillCard.addView(
            textColumn,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        pillCard.addView(waveView, LinearLayout.LayoutParams(dp(24), dp(18)))

        val collapsedW = dp(136)
        val collapsedH = dp(36)
        pillBg.cornerRadius = collapsedH / 2f
        pillCard.setPadding(dp(10), dp(6), dp(10), dp(6))

        rootContainer.addView(
            pillCard,
            FrameLayout.LayoutParams(collapsedW, collapsedH, Gravity.CENTER_HORIZONTAL)
        )

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            dp(360),
            dp(120),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(10)
        }

        setupTouchAndGestures()
        windowManager.addView(rootContainer, layoutParams)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouchAndGestures() {
        var initialY = 0f
        pillCard.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = event.rawY
                    v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(110).start()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
                    val dy = event.rawY - initialY
                    if (dy < -dp(18) && isExpanded) {
                        animateToState(expanded = false)
                    } else {
                        animateToState(expanded = !isExpanded)
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
                    true
                }
                else -> false
            }
        }
    }

    private fun observeBus() {
        serviceScope.launch {
            Bus.events.collect { event ->
                when (event) {
                    is IslandEvent.NotificationArrived -> {
                        titleView.text = event.title.ifBlank { "Bildirishnoma" }
                        subtitleView.text = event.text
                        waveView.setAnimating(true)
                        animateToState(expanded = true, autoCollapseMs = 4500L)

                        val summary = AiClient.summarizeNotification(event.title, event.text)
                        if (isExpanded) subtitleView.text = summary
                    }
                    is IslandEvent.AiReply -> {
                        titleView.text = "Orol AI"
                        subtitleView.text = event.message
                        animateToState(expanded = true, autoCollapseMs = 5000L)
                    }
                    IslandEvent.Expand -> animateToState(expanded = true)
                    IslandEvent.Collapse -> animateToState(expanded = false)
                }
            }
        }
    }

    private fun animateToState(expanded: Boolean, autoCollapseMs: Long? = null) {
        isExpanded = expanded
        collapseJob?.cancel()

        val startW = pillCard.layoutParams.width
        val startH = pillCard.layoutParams.height
        val targetW = if (expanded) dp(336) else dp(136)
        val targetH = if (expanded) dp(78) else dp(36)

        val orbTarget = if (expanded) dp(42) else dp(24)
        orbView.layoutParams = (orbView.layoutParams as LinearLayout.LayoutParams).apply {
            width = orbTarget
            height = orbTarget
        }

        if (expanded) {
            textColumn.visibility = View.VISIBLE
            textColumn.alpha = 0f
            textColumn.animate().alpha(1f).setStartDelay(90).setDuration(200).start()
            pillCard.setPadding(dp(14), dp(10), dp(14), dp(10))
        } else {
            textColumn.visibility = View.GONE
            pillCard.setPadding(dp(10), dp(6), dp(10), dp(6))
        }

        val spring = SpringAnimation(pillCard, DynamicAnimation.SCALE_X, 1f).apply {
            spring = SpringForce(1f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
        }

        val morph = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (expanded) 380L else 300L
            interpolator = android.view.animation.OvershootInterpolator(if (expanded) 1.15f else 0.6f)
            addUpdateListener { anim ->
                val f = anim.animatedValue as Float
                val curW = (startW + (targetW - startW) * f).toInt()
                val curH = (startH + (targetH - startH) * f).toInt()
                pillCard.layoutParams = (pillCard.layoutParams as FrameLayout.LayoutParams).apply {
                    width = curW
                    height = curH
                    gravity = Gravity.CENTER_HORIZONTAL
                }
                val targetRadius = if (expanded) dp(28).toFloat() else (curH / 2f)
                pillBg.cornerRadius = targetRadius
                pillCard.requestLayout()
            }
        }
        morph.start()
        spring.start()

        if (expanded && autoCollapseMs != null) {
            collapseJob = serviceScope.launch {
                delay(autoCollapseMs)
                animateToState(expanded = false)
            }
        }
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()

    override fun onDestroy() {
        collapseJob?.cancel()
        serviceScope.cancel()
        if (::rootContainer.isInitialized) {
            windowManager.removeView(rootContainer)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
