package uz.orol.island

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

sealed class IslandEvent {
    data class NotificationArrived(
        val title: String,
        val text: String,
        val packageName: String,
        val isMedia: Boolean = false
    ) : IslandEvent()

    data class AiReply(val message: String) : IslandEvent()
    object Collapse : IslandEvent()
    object Expand : IslandEvent()
}

object Bus {
    private val _events = MutableSharedFlow<IslandEvent>(extraBufferCapacity = 32)
    val events = _events.asSharedFlow()

    fun emit(event: IslandEvent) {
        _events.tryEmit(event)
    }
}
