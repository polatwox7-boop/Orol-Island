package uz.orol.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

class OrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var pulseScale = 1f

    private val colors = intArrayOf(
        Color.parseColor("#38BDF8"),
        Color.parseColor("#818CF8"),
        Color.parseColor("#E879F9"),
        Color.parseColor("#2DD4BF"),
        Color.parseColor("#38BDF8")
    )

    private val animator = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 3200L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            pulseScale = 0.92f + 0.08f * sin(phase * 2f)
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isStarted) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (minOf(width, height) / 2f) * 0.78f * pulseScale
        if (baseRadius <= 0f) return

        val matrix = Matrix().apply {
            setRotate(Math.toDegrees(phase.toDouble()).toFloat(), cx, cy)
        }
        val sweep = SweepGradient(cx, cy, colors, null).apply {
            setLocalMatrix(matrix)
        }

        glowPaint.shader = sweep
        glowPaint.alpha = 110
        canvas.drawCircle(cx, cy, baseRadius * 1.18f, glowPaint)

        val ox = cx + cos(phase) * (baseRadius * 0.25f)
        val oy = cy + sin(phase) * (baseRadius * 0.25f)
        paint.shader = RadialGradient(
            ox, oy, baseRadius * 1.15f,
            intArrayOf(
                Color.WHITE,
                Color.parseColor("#60A5FA"),
                Color.parseColor("#A855F7"),
                Color.parseColor("#0F172A")
            ),
            floatArrayOf(0f, 0.35f, 0.75f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, baseRadius, paint)
    }
}
