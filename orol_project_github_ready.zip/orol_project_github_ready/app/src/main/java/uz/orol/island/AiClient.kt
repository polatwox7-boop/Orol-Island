package uz.orol.island

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object AiClient {
    suspend fun summarizeNotification(title: String, text: String): String =
        withContext(Dispatchers.IO) {
            delay(350L)
            val cleanTitle = title.ifBlank { "Orol Island" }
            val cleanText = text.ifBlank { "Yangi bildirishnoma keldi" }
            if (cleanText.length > 52) {
                "$cleanTitle: ${cleanText.take(49)}..."
            } else {
                "$cleanTitle — $cleanText"
            }
        }
}
