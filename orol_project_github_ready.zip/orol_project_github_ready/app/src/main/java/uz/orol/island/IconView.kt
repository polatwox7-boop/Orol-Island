package uz.orol.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.sin

class IconView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#38BDF8")
        style = Paint.Style.FILL
    }
    private val rect = RectF()
    private var tick = 0f
    private var active = true

    private val waveAnimator = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 1100L
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            tick = it.animatedValue as Float
            invalidate()
        }
    }

    fun setAnimating(isAnimating: Boolean) {
        active = isAnimating
        if (active && !waveAnimator.isStarted) waveAnimator.start()
        else if (!active) {
            waveAnimator.cancel()
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (active) waveAnimator.start()
    }

    override fun onDetachedFromWindow() {
        waveAnimator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bars = 4
        val gap = width * 0.10f
        val barWidth = (width - gap * (bars + 1)) / bars
        val maxH = height * 0.75f
        val minH = height * 0.22f
        val centerY = height / 2f

        for (i in 0 until bars) {
            val factor = if (active) {
                0.5f + 0.5f * sin(tick + i * 1.15f)
            } else {
                0.15f
            }
            val barH = minH + (maxH - minH) * factor
            val left = gap + i * (barWidth + gap)
            rect.set(left, centerY - barH / 2f, left + barWidth, centerY + barH / 2f)
            canvas.drawRoundRect(rect, barWidth / 2f, barWidth / 2f, barPaint)
        }
    }
}
