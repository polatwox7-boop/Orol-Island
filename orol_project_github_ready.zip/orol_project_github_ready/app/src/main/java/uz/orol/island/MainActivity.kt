package uz.orol.island

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                200
            )
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#000000"))
            setPadding(dp(22), dp(48), dp(22), dp(24))
        }

        val orbPreview = OrbView(this)
        root.addView(orbPreview, LinearLayout.LayoutParams(dp(84), dp(84)))

        val heading = TextView(this).apply {
            text = "Orol Island • iOS"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            paint.isFakeBoldText = true
            setPadding(0, dp(16), 0, dp(6))
        }
        root.addView(heading)

        val sub = TextView(this).apply {
            text = "Dynamic Island prujinali animatsiyalar va jonli bildirishnomalar"
            setTextColor(Color.parseColor("#98989F"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(28))
        }
        root.addView(sub)

        root.addView(iosButton("1. Ekran ustida ko'rsatish ruxsati", "#1C1C1E") {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        })

        root.addView(iosButton("2. Bildirishnomalarni o'qish ruxsati", "#1C1C1E") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        root.addView(iosButton("3. Dynamic Island ni ishga tushirish", "#0A84FF") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                return@iosButton
            }
            val serviceIntent = Intent(this, IslandService::class.java)
            ContextCompat.startForegroundService(this, serviceIntent)
        })

        root.addView(iosButton("4. Sinov animatsiyasi (iOS Notification)", "#30D158") {
            Bus.emit(
                IslandEvent.NotificationArrived(
                    title = "Apple Music • Synthwave",
                    text = "Orol Dynamic Island iOS prujinali animatsiya sinovi",
                    packageName = packageName,
                    isMedia = true
                )
            )
        })

        setContentView(root)
    }

    private fun iosButton(label: String, hexColor: String, onClick: () -> Unit): Button {
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(hexColor))
            cornerRadius = dp(16).toFloat()
        }
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = bg
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(12)
            }
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
}
