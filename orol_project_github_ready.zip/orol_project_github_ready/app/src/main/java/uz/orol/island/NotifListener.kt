package uz.orol.island

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notif = sbn?.notification ?: return
        if (sbn.packageName == packageName) return
        if ((notif.flags and Notification.FLAG_ONGOING_EVENT) != 0 &&
            notif.category != Notification.CATEGORY_TRANSPORT
        ) return

        val extras = notif.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val isMedia = notif.category == Notification.CATEGORY_TRANSPORT ||
            extras.containsKey(Notification.EXTRA_MEDIA_SESSION)

        Bus.emit(
            IslandEvent.NotificationArrived(
                title = title,
                text = text,
                packageName = sbn.packageName,
                isMedia = isMedia
            )
        )
    }
}
