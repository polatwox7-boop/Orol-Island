package uz.orol.island

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.min

class IconView(c: Context) : View(c) {
    companion object {
        const val NONE = 0
        const val HOTSPOT = 1
        const val BOLT = 2
        const val BELL = 3
        const val ALARM = 4
        const val TIMER = 5
        const val STOPWATCH = 6
        const val MUSIC = 7
        const val AI = 8
        const val CALL = 9
        const val BATTERY = 10
        const val ISLAND = 11
    }

    var type = NONE
        set(v) { field = v; invalidate() }
    var level = 0f
        set(v) { field = v; invalidate() }
    var tint = Color.WHITE
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f * 0.82f
        p.color = tint
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = r * 0.16f
        when (type) {
            HOTSPOT -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.2f, p)
                p.style = Paint.Style.STROKE
                for (k in 1..2) {
                    val rr = r * (0.42f * k + 0.08f)
                    val rect = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
                    c.drawArc(rect, -52f, 104f, false, p)
                    c.drawArc(rect, 128f, 104f, false, p)
                }
            }
            BOLT -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(cx + r * 0.2f, cy - r * 0.95f)
                path.lineTo(cx - r * 0.5f, cy + r * 0.1f)
                path.lineTo(cx - r * 0.05f, cy + r * 0.1f)
                path.lineTo(cx - r * 0.2f, cy + r * 0.95f)
                path.lineTo(cx + r * 0.5f, cy - r * 0.15f)
                path.lineTo(cx + r * 0.05f, cy - r * 0.15f)
                path.close()
                c.drawPath(path, p)
            }
            BELL -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(cx - r * 0.7f, cy + r * 0.5f)
                path.quadTo(cx - r * 0.55f, cy + r * 0.3f, cx - r * 0.55f, cy - r * 0.1f)
                path.cubicTo(cx - r * 0.55f, cy - r * 0.85f, cx + r * 0.55f, cy - r * 0.85f, cx + r * 0.55f, cy - r * 0.1f)
                path.quadTo(cx + r * 0.55f, cy + r * 0.3f, cx + r * 0.7f, cy + r * 0.5f)
                path.close()
                c.drawPath(path, p)
                c.drawCircle(cx, cy + r * 0.75f, r * 0.17f, p)
            }
            ALARM, TIMER, STOPWATCH -> {
                p.style = Paint.Style.STROKE
                val rr = r * 0.72f
                c.drawCircle(cx, cy + r * 0.1f, rr, p)
                c.drawLine(cx, cy + r * 0.1f, cx, cy - rr * 0.5f + r * 0.1f, p)
                c.drawLine(cx, cy + r * 0.1f, cx + rr * 0.45f, cy + r * 0.1f, p)
                if (type == ALARM) {
                    c.drawLine(cx - rr * 0.9f, cy - rr * 0.65f, cx - rr * 0.55f, cy - rr * 0.95f, p)
                    c.drawLine(cx + rr * 0.9f, cy - rr * 0.65f, cx + rr * 0.55f, cy - rr * 0.95f, p)
                } else {
                    c.drawLine(cx - r * 0.2f, cy - r * 0.85f, cx + r * 0.2f, cy - r * 0.85f, p)
                }
            }
            MUSIC -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx - r * 0.3f, cy + r * 0.55f, r * 0.3f, p)
                p.style = Paint.Style.STROKE
                c.drawLine(cx - r * 0.02f, cy + r * 0.5f, cx - r * 0.02f, cy - r * 0.8f, p)
                path.reset()
                path.moveTo(cx - r * 0.02f, cy - r * 0.8f)
                path.quadTo(cx + r * 0.5f, cy - r * 0.6f, cx + r * 0.5f, cy - r * 0.1f)
                c.drawPath(path, p)
            }
            AI -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(cx, cy - r)
                path.quadTo(cx, cy, cx + r, cy)
                path.quadTo(cx, cy, cx, cy + r)
                path.quadTo(cx, cy, cx - r, cy)
                path.quadTo(cx, cy, cx, cy - r)
                path.close()
                c.drawPath(path, p)
            }
            CALL -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.3f
                val rect = RectF(cx - r * 0.75f, cy - r * 0.2f, cx + r * 0.75f, cy + r * 1.2f)
                c.drawArc(rect, 200f, 140f, false, p)
            }
            BATTERY -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.22f
                val rect = RectF(cx - r * 0.8f, cy - r * 0.8f, cx + r * 0.8f, cy + r * 0.8f)
                p.alpha = 70
                c.drawArc(rect, 0f, 360f, false, p)
                p.alpha = 255
                p.color = Color.parseColor("#6BE38F")
                c.drawArc(rect, -90f, 360f * level, false, p)
                p.color = tint
                p.style = Paint.Style.FILL
                val s = 0.42f
                path.reset()
                path.moveTo(cx + r * 0.1f * s * 2, cy - r * 0.5f)
                path.lineTo(cx - r * 0.3f, cy + r * 0.05f)
                path.lineTo(cx - r * 0.02f, cy + r * 0.05f)
                path.lineTo(cx - r * 0.12f, cy + r * 0.5f)
                path.lineTo(cx + r * 0.3f, cy - r * 0.1f)
                path.lineTo(cx + r * 0.03f, cy - r * 0.1f)
                path.close()
                c.drawPath(path, p)
            }
            ISLAND -> {
                p.style = Paint.Style.STROKE
                val rect = RectF(cx - r, cy - r * 0.45f, cx + r, cy + r * 0.45f)
                c.drawRoundRect(rect, r * 0.45f, r * 0.45f, p)
            }
        }
    }
}
