package uz.orol.island

import android.app.PendingIntent
import android.graphics.drawable.Drawable

data class Evt(
    val icon: String,
    val title: String,
    val text: String = "",
    val ms: Long = 4000,
    val pi: PendingIntent? = null,
    val appIcon: Drawable? = null,
    val sticky: Boolean = false,
    val key: String = "",
    val actions: List<Pair<String, PendingIntent>> = emptyList(),
    val pkg: String = ""
)

object Bus {
    @Volatile var listener: ((Evt) -> Unit)? = null
    @Volatile var removeListener: ((String) -> Unit)? = null
    @Volatile var ask: ((String) -> Unit)? = null

    fun post(e: Evt) { listener?.invoke(e) }
    fun remove(k: String) { removeListener?.invoke(k) }
}
