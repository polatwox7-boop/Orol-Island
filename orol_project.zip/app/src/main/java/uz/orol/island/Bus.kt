package uz.orol.island

import android.app.PendingIntent

data class Evt(
    val icon: String,
    val title: String,
    val text: String = "",
    val ms: Long = 4000,
    val pi: PendingIntent? = null
)

object Bus {
    @Volatile
    var listener: ((Evt) -> Unit)? = null

    fun post(e: Evt) {
        listener?.invoke(e)
    }
}
