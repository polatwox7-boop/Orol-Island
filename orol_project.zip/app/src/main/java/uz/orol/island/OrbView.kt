package uz.orol.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

class OrbView(c: Context) : View(c) {
    private var phase = 0f
    var speed = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1300
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { phase = it.animatedFraction; invalidate() }
    }

    fun start() { if (!anim.isRunning) anim.start() }
    fun stop() { anim.cancel() }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        val s = 0.78f + 0.2f * sin(phase * 2f * PI.toFloat() * speed)
        p.shader = RadialGradient(
            cx, cy, r * s,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFB388FF.toInt(), 0xFF4FC3F7.toInt(), 0x004FC3F7),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * s, p)
    }
}
