package uz.orol.island

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var st1: TextView
    private lateinit var st2: TextView
    private lateinit var run: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, act: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(14), dp(14), dp(14), dp(14))
        val g = GradientDrawable()
        g.setColor(0xFF111111.toInt())
        g.cornerRadius = dp(18).toFloat()
        b.background = g
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(8), 0, 0)
        b.layoutParams = lp
        b.setOnClickListener { act() }
        return b
    }

    private fun label(t: String, size: Float, bold: Boolean = false, color: Int = 0xFF222222.toInt()): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, dp(6), 0, dp(2))
        return v
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(24))
        col.addView(label("Orol", 30f, true))
        col.addView(label("Kamera atrofida Dynamic Island: bildirishnoma, sekundomer, taymer, hotspot va zaryad holati.", 14f, false, 0xFF555555.toInt()))
        st1 = label("", 14f, true)
        st2 = label("", 14f, true)
        run = label("", 14f, true)
        col.addView(st1)
        col.addView(button("1. Boshqa ilovalar ustida ko‘rsatish ruxsati") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(st2)
        col.addView(button("2. Bildirishnomalarni o‘qishga ruxsat") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("3. Batareya cheklovini o‘chirish (tavsiya)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        col.addView(run)
        col.addView(button("Orolni yoqish / o‘chirish") { toggle() })
        col.addView(button("Sinab ko‘rish") {
            if (IslandService.running) Bus.post(Evt("🔔", "Sinov xabari", "Orol ishlayapti ✓", 4000))
            else Toast.makeText(this, "Avval orolni yoqing", Toast.LENGTH_SHORT).show()
        })
        val cb = CheckBox(this)
        cb.text = "Orol doim ko‘rinib tursin (kamera atrofida)"
        cb.isChecked = getSharedPreferences("orol", MODE_PRIVATE).getBoolean("always", true)
        cb.setOnCheckedChangeListener { _, v -> getSharedPreferences("orol", MODE_PRIVATE).edit().putBoolean("always", v).apply() }
        col.addView(cb)
        col.addView(label("Orolga bossangiz kengayadi: sekundomer, 1/5/10 daqiqalik taymer, batareya va hotspot holati ko‘rinadi. Bildirishnomaga bossangiz, o‘sha ilova ochiladi. Ba’zi telefonlarda (masalan Huawei) ilova avtomatik ishga tushirish va fon rejimiga ruxsat so‘rashi mumkin.", 12.5f, false, 0xFF777777.toInt()))
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun listenerOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun refreshStatus() {
        st1.text = if (Settings.canDrawOverlays(this)) "✓ Ustiga chizish ruxsati berilgan" else "✗ Ustiga chizish ruxsati kerak"
        st2.text = if (listenerOn()) "✓ Bildirishnomalarga ruxsat berilgan" else "✗ Bildirishnomalarga ruxsat kerak"
        run.text = if (IslandService.running) "● Orol ishlayapti" else "○ Orol o‘chiq"
    }

    private fun toggle() {
        if (IslandService.running) {
            stopService(Intent(this, IslandService::class.java))
            run.postDelayed({ refreshStatus() }, 300)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Avval 1-ruxsatni bering", Toast.LENGTH_LONG).show()
                return
            }
            startForegroundService(Intent(this, IslandService::class.java))
            run.postDelayed({ refreshStatus() }, 500)
        }
    }
}
