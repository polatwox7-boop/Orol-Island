package uz.orol.island

import android.Manifest
import android.animation.ValueAnimator
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class IslandService : Service() {
    companion object {
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var pill: LinearLayout
    private lateinit var outerG: GradientDrawable
    private lateinit var innerG: GradientDrawable
    private lateinit var row: LinearLayout
    private lateinit var appIc: ImageView
    private lateinit var iv: IconView
    private lateinit var ti: TextView
    private lateinit var rt: TextView
    private lateinit var msg: TextView
    private lateinit var actRow: LinearLayout
    private lateinit var musicRow: LinearLayout
    private lateinit var musicTx: TextView
    private lateinit var playBtn: TextView
    private lateinit var info: TextView
    private lateinit var ctrl: LinearLayout
    private lateinit var swBtn: TextView
    private lateinit var aiRow: LinearLayout
    private lateinit var orb: OrbView
    private lateinit var aiTx: TextView
    private lateinit var lp: WindowManager.LayoutParams

    private var attached = false
    private var mode = 0 // 0 idle, 1 compact, 2 toast, 3 expanded, 4 ai
    private var toastUntil = 0L
    private var toastPi: PendingIntent? = null
    private var toastKey = ""
    private var aiUntil = 0L
    private var swRun = false
    private var swStart = 0L
    private var swAcc = 0L
    private var tmRun = false
    private var tmEnd = 0L
    private var hotspot = false
    private var hotspotKnown = false
    private var plugged = false
    private var pluggedKnown = false
    private var battery = 0
    private var lowShown = false
    private var cutX = 0
    private var cutW = 0
    private var cutH = 0
    private var animator: ValueAnimator? = null
    private var tickCount = 0
    private var mc: MediaController? = null
    private var musicTitle = ""
    private var musicArtist = ""
    private var musicPlaying = false
    private var lastTrack = ""
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun prefs() = getSharedPreferences("orol", MODE_PRIVATE)
    private fun always() = prefs().getBoolean("always", true)

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        build()
        Bus.listener = { e -> ui.post { toast(e) } }
        Bus.removeListener = { k -> ui.post { if (k == toastKey) toastUntil = 0 } }
        Bus.ask = { q -> ui.post { askAi(q) } }
        registerReceivers()
        ui.post(tickRun)
    }

    override fun onDestroy() {
        running = false
        Bus.listener = null
        Bus.removeListener = null
        Bus.ask = null
        ui.removeCallbacksAndMessages(null)
        animator?.cancel()
        try { unregisterReceiver(rcv) } catch (e: Exception) {}
        try { rec?.destroy() } catch (e: Exception) {}
        try { tts?.shutdown() } catch (e: Exception) {}
        orb.stop()
        if (attached) {
            try { wm.removeView(pill) } catch (e: Exception) {}
            attached = false
        }
        super.onDestroy()
    }

    private fun startAsForeground() {
        val ch = "orol"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Orol", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Orol ishlayapti")
            .setContentText("Kamera atrofidagi orol yoqilgan")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    private fun tv(size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        t.includeFontPadding = false
        return t
    }

    private fun btn(label: String, act: () -> Unit): TextView {
        val b = tv(13f, Color.WHITE, true)
        b.text = label
        b.gravity = Gravity.CENTER
        b.setPadding(dp(8), dp(10), dp(8), dp(10))
        val g = GradientDrawable()
        g.setColor(0x33FFFFFF)
        g.setStroke(dp(1), 0x44FFFFFF)
        g.cornerRadius = dp(16).toFloat()
        b.background = g
        b.setOnClickListener { act() }
        return b
    }

    private fun build() {
        val blur = Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled
        outerG = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xCCFFFFFF.toInt(), 0x22FFFFFF, 0x99FFFFFF.toInt()))
        innerG = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(if (blur) 0xA83A4258.toInt() else 0xE6343B50.toInt(), if (blur) 0xA8202636.toInt() else 0xE61F2433.toInt()))
        val ld = LayerDrawable(arrayOf(outerG, innerG))
        ld.setLayerInset(1, dp(1), dp(1), dp(1), dp(1))
        pill = LinearLayout(this)
        pill.orientation = LinearLayout.VERTICAL
        pill.background = ld
        pill.elevation = dp(8).toFloat()

        row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        appIc = ImageView(this)
        iv = IconView(this)
        ti = tv(15f, Color.WHITE, true)
        ti.maxLines = 1
        ti.ellipsize = TextUtils.TruncateAt.END
        ti.setPadding(dp(10), 0, dp(10), 0)
        rt = tv(12.5f, 0xFFD0D6E4.toInt())
        row.addView(appIc, LinearLayout.LayoutParams(dp(34), dp(34)))
        row.addView(iv, LinearLayout.LayoutParams(dp(28), dp(28)))
        row.addView(ti, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(rt)

        msg = tv(13.5f, 0xFFE6EAF4.toInt())
        msg.maxLines = 3
        msg.ellipsize = TextUtils.TruncateAt.END
        msg.setPadding(0, dp(8), 0, 0)

        actRow = LinearLayout(this)
        actRow.orientation = LinearLayout.HORIZONTAL
        actRow.setPadding(0, dp(10), 0, 0)

        musicRow = LinearLayout(this)
        musicRow.orientation = LinearLayout.HORIZONTAL
        musicRow.gravity = Gravity.CENTER_VERTICAL
        musicRow.setPadding(0, dp(10), 0, 0)
        val mi = IconView(this)
        mi.type = IconView.MUSIC
        musicTx = tv(13f, Color.WHITE)
        musicTx.maxLines = 1
        musicTx.ellipsize = TextUtils.TruncateAt.END
        musicTx.setPadding(dp(8), 0, dp(8), 0)
        playBtn = btn(">") { musicToggle() }
        musicRow.addView(mi, LinearLayout.LayoutParams(dp(22), dp(22)))
        musicRow.addView(musicTx, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        musicRow.addView(btn("|<") { mc?.transportControls?.skipToPrevious() }, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), 0, dp(2), 0) })
        musicRow.addView(playBtn, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), 0, dp(2), 0) })
        musicRow.addView(btn(">|") { mc?.transportControls?.skipToNext() }, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), 0, dp(2), 0) })

        info = tv(12.5f, 0xFFC4CBDD.toInt())
        info.setPadding(0, dp(10), 0, 0)

        ctrl = LinearLayout(this)
        ctrl.orientation = LinearLayout.HORIZONTAL
        ctrl.setPadding(0, dp(10), 0, 0)
        swBtn = btn("Sekundomer") { toggleStopwatch() }
        val lpB = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) } }
        ctrl.addView(swBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2.4f).apply { setMargins(dp(2), 0, dp(2), 0) })
        ctrl.addView(btn("Nol") { resetAll() }, lpB())
        ctrl.addView(btn("1m") { startTimer(60) }, lpB())
        ctrl.addView(btn("5m") { startTimer(300) }, lpB())
        ctrl.addView(btn("10m") { startTimer(600) }, lpB())
        ctrl.addView(btn("AI") { startAi() }, lpB())

        aiRow = LinearLayout(this)
        aiRow.orientation = LinearLayout.HORIZONTAL
        aiRow.gravity = Gravity.CENTER_VERTICAL
        aiRow.setPadding(0, dp(10), 0, 0)
        orb = OrbView(this)
        aiTx = tv(14f, Color.WHITE)
        aiTx.maxLines = 6
        aiTx.setPadding(dp(12), 0, 0, 0)
        aiRow.addView(orb, LinearLayout.LayoutParams(dp(46), dp(46)))
        aiRow.addView(aiTx, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        pill.addView(row)
        pill.addView(msg)
        pill.addView(actRow)
        pill.addView(musicRow)
        pill.addView(info)
        pill.addView(ctrl)
        pill.addView(aiRow)
        pill.setOnClickListener { onPillClick() }

        readCutout()
        lp = WindowManager.LayoutParams(
            idleW(), idleH(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (blur) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = dp(28)
        }
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.x = if (cutW > 0) cutX - screenW() / 2 else 0
        lp.y = if (cutW > 0) 0 else dp(6)
        try { wm.addView(pill, lp); attached = true } catch (e: Exception) { attached = false }
        val shimmer = ValueAnimator.ofInt(150, 255)
        shimmer.duration = 2200
        shimmer.repeatMode = ValueAnimator.REVERSE
        shimmer.repeatCount = ValueAnimator.INFINITE
        shimmer.addUpdateListener { outerG.alpha = it.animatedValue as Int }
        shimmer.start()
        setMode(0, false)
    }

    private fun readCutout() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val dc = wm.currentWindowMetrics.windowInsets.displayCutout
                val r = dc?.boundingRects?.firstOrNull { it.top <= 2 }
                if (r != null) { cutX = r.centerX(); cutW = r.width(); cutH = r.bottom }
            }
        } catch (e: Exception) {}
    }

    private fun idleW() = max(cutW + dp(28), dp(110))
    private fun idleH() = max(cutH + dp(10), dp(38))
    private fun compactW() = dp(210)
    private fun wideW() = min(screenW() - dp(20), dp(390))

    private fun targetH(w: Int): Int {
        pill.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        return max(pill.measuredHeight, if (mode == 0) idleH() else dp(56))
    }

    private fun animateTo(w: Int, h: Int) {
        animator?.cancel()
        if (!attached) return
        val w0 = lp.width
        val h0 = if (lp.height > 0) lp.height else h
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 380
        a.interpolator = OvershootInterpolator(1.1f)
        a.addUpdateListener {
            val t = it.animatedValue as Float
            lp.width = (w0 + (w - w0) * t).toInt()
            lp.height = max(dp(24), (h0 + (h - h0) * t).toInt())
            try { wm.updateViewLayout(pill, lp) } catch (e: Exception) {}
        }
        animator = a
        a.start()
    }

    private fun fade(vararg v: View) {
        for (x in v) {
            if (x.visibility == View.VISIBLE) {
                x.alpha = 0f
                x.scaleX = 0.92f
                x.scaleY = 0.92f
                x.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setStartDelay(90).start()
            }
        }
    }

    private fun base() = if (tmRun || swRun || musicPlaying) 1 else 0

    private fun setMode(m: Int, animate: Boolean = true) {
        mode = m
        val idle = m == 0
        pill.visibility = if (idle && !always()) View.GONE else View.VISIBLE
        pill.minimumHeight = if (idle) idleH() else dp(56)
        val ph = if (idle) dp(10) else dp(14)
        pill.setPadding(ph, if (idle) 0 else dp(12), ph, if (idle) 0 else dp(12))
        row.visibility = if (idle) View.GONE else View.VISIBLE
        msg.visibility = if (m == 2 && msg.text.isNotEmpty()) View.VISIBLE else View.GONE
        actRow.visibility = if (m == 2 && actRow.childCount > 0) View.VISIBLE else View.GONE
        musicRow.visibility = if (m == 3 && musicTitle.isNotEmpty()) View.VISIBLE else View.GONE
        info.visibility = if (m == 3) View.VISIBLE else View.GONE
        ctrl.visibility = if (m == 3) View.VISIBLE else View.GONE
        aiRow.visibility = if (m == 4) View.VISIBLE else View.GONE
        if (m == 4) orb.start() else orb.stop()
        val r = dp(when (m) { 0 -> 20; 1 -> 28; 2 -> 30; else -> 34 }).toFloat()
        outerG.cornerRadius = r
        innerG.cornerRadius = max(0f, r - dp(1))
        updateTexts()
        val w = when (m) { 0 -> idleW(); 1 -> compactW(); else -> wideW() }
        val h = targetH(w)
        if (animate) animateTo(w, h) else { lp.width = w; lp.height = h; if (attached) try { wm.updateViewLayout(pill, lp) } catch (e: Exception) {} }
        fade(row, msg, actRow, musicRow, info, ctrl, aiRow)
    }

    private fun setIcon(type: Int, app: android.graphics.drawable.Drawable? = null) {
        if (app != null) {
            appIc.setImageDrawable(app)
            appIc.visibility = View.VISIBLE
            iv.visibility = View.GONE
        } else {
            appIc.visibility = View.GONE
            iv.visibility = View.VISIBLE
            iv.type = type
        }
    }

    private fun toast(e: Evt) {
        if (mode == 4) return
        setIcon(iconFor(e), e.appIcon)
        ti.text = e.title
        rt.text = ""
        msg.text = e.text
        toastPi = e.pi
        toastKey = e.key
        toastUntil = if (e.sticky) Long.MAX_VALUE else System.currentTimeMillis() + e.ms
        actRow.removeAllViews()
        for (a in e.actions) {
            actRow.addView(btn(a.first) {
                try { a.second.send() } catch (x: Exception) {}
                toastUntil = 0
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        if (e.icon == "charge") {
            iv.level = battery / 100f
            val a = ValueAnimator.ofFloat(0f, battery / 100f)
            a.duration = 900
            a.addUpdateListener { iv.level = it.animatedValue as Float }
            a.start()
        }
        setMode(2)
    }

    private fun iconFor(e: Evt): Int = when (e.icon) {
        "hotspot" -> IconView.HOTSPOT
        "charge" -> IconView.BATTERY
        "bolt" -> IconView.BOLT
        "alarm" -> IconView.ALARM
        "timer" -> IconView.TIMER
        "ai" -> IconView.AI
        "music" -> IconView.MUSIC
        "call" -> IconView.CALL
        else -> IconView.BELL
    }

    private fun onPillClick() {
        if (mode == 2) {
            val p = toastPi
            if (p != null) {
                try { p.send() } catch (e: Exception) {}
                toastUntil = 0
                return
            }
        }
        if (mode == 4) { aiUntil = 0; try { rec?.cancel() } catch (e: Exception) {}; setMode(base()); return }
        if (mode == 3) setMode(base()) else setMode(3)
    }

    private fun toggleStopwatch() {
        if (swRun) { swAcc += System.currentTimeMillis() - swStart; swRun = false } else { swStart = System.currentTimeMillis(); swRun = true }
        updateTexts()
    }

    private fun resetAll() { swRun = false; swAcc = 0; tmRun = false; updateTexts() }
    private fun startTimer(sec: Int) { tmEnd = System.currentTimeMillis() + sec * 1000L; tmRun = true; updateTexts() }
    private fun elapsed() = swAcc + if (swRun) System.currentTimeMillis() - swStart else 0L

    private fun fmt(ms: Long): String {
        val t = max(0L, ms)
        return String.format("%02d:%02d.%d", t / 60000, (t / 1000) % 60, (t / 100) % 10)
    }

    private fun nextAlarm(): String {
        val a = (getSystemService(Context.ALARM_SERVICE) as AlarmManager).nextAlarmClock ?: return "yo‘q"
        val c = Calendar.getInstance()
        c.timeInMillis = a.triggerTime
        val t = String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        val td = Calendar.getInstance()
        return if (c.get(Calendar.DAY_OF_YEAR) == td.get(Calendar.DAY_OF_YEAR)) t else "$t (keyingi kun)"
    }

    private fun updateTexts() {
        if (mode == 1 || mode == 3) {
            if (tmRun) { setIcon(IconView.TIMER); ti.text = fmt(tmEnd - System.currentTimeMillis()); rt.text = "Taymer" }
            else if (swRun || swAcc > 0) { setIcon(IconView.STOPWATCH); ti.text = fmt(elapsed()); rt.text = "Sekundomer" }
            else if (musicPlaying && musicTitle.isNotEmpty()) { setIcon(IconView.MUSIC); ti.text = musicTitle; rt.text = musicArtist }
            else { setIcon(IconView.ISLAND); ti.text = "Orol"; rt.text = "" }
        }
        if (mode == 3) {
            swBtn.text = if (swRun) "Pauza" else "Sekundomer"
            val c = Calendar.getInstance()
            val hm = String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
            info.text = "Batareya $battery%" + (if (plugged) " (zaryadda)" else "") + "  |  Hotspot: " + (if (hotspot) "yoqiq" else "o‘chiq") + "\nBudilnik: " + nextAlarm() + "  |  Soat: $hm"
            musicTx.text = if (musicArtist.isEmpty()) musicTitle else "$musicTitle · $musicArtist"
            playBtn.text = if (musicPlaying) "||" else ">"
        }
    }

    private val tickRun = object : Runnable {
        override fun run() {
            tickCount++
            val now = System.currentTimeMillis()
            if (tmRun && now >= tmEnd) {
                tmRun = false
                vibrate()
                toast(Evt("alarm", "Taymer tugadi", "", 5000))
            } else if (mode == 2 && now > toastUntil) {
                setMode(base())
            } else if (mode == 4 && aiUntil > 0 && now > aiUntil) {
                setMode(base())
            } else if (mode == 1 && base() != 1) {
                setMode(0)
            } else if (mode == 0 && base() == 1) {
                setMode(1)
            } else {
                updateTexts()
            }
            if (tickCount % 10 == 0) pollMusic()
            if (tickCount % 50 == 0) pollHotspot()
            ui.postDelayed(this, if (swRun || tmRun || mode == 3) 100L else 400L)
        }
    }

    private fun pollMusic() {
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, NotifListener::class.java))
            var f: MediaController? = null
            for (c in list) if (c.playbackState?.state == PlaybackState.STATE_PLAYING) { f = c; break }
            if (f == null && list.isNotEmpty()) f = list[0]
            mc = f
            musicTitle = f?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            musicArtist = f?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
            musicPlaying = f?.playbackState?.state == PlaybackState.STATE_PLAYING
            if (musicPlaying && musicTitle.isNotEmpty() && musicTitle != lastTrack) {
                if (lastTrack.isNotEmpty() && mode != 4) toast(Evt("music", musicTitle, musicArtist, 3500))
                lastTrack = musicTitle
            }
        } catch (e: Exception) {
            mc = null
            musicPlaying = false
            musicTitle = ""
        }
    }

    private fun musicToggle() {
        val t = mc?.transportControls ?: return
        if (musicPlaying) t.pause() else t.play()
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300, 150, 300), -1))
        } catch (e: Exception) {}
    }

    private fun setHotspot(on: Boolean) {
        val changed = hotspotKnown && on != hotspot
        hotspot = on
        hotspotKnown = true
        if (changed) toast(Evt("hotspot", if (on) "Hotspot yoqildi" else "Hotspot o‘chirildi", "", 3500))
    }

    private fun pollHotspot() {
        try {
            val wf = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val m = wf.javaClass.getDeclaredMethod("isWifiApEnabled")
            m.isAccessible = true
            setHotspot(m.invoke(wf) as Boolean)
        } catch (e: Throwable) {}
    }

    private fun handleBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        battery = if (level >= 0 && scale > 0) level * 100 / scale else battery
        val pl = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val changed = pluggedKnown && pl != plugged
        plugged = pl
        pluggedKnown = true
        if (changed) toast(Evt(if (pl) "charge" else "bolt", if (pl) "Zaryadlanmoqda" else "Zaryad uzildi", "Batareya $battery%", 4000))
        if (!pl && battery in 1..15 && !lowShown) { lowShown = true; toast(Evt("bolt", "Batareya kam", "$battery% qoldi", 4500)) }
        if (battery > 20) lowShown = false
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> handleBattery(i)
                Intent.ACTION_POWER_CONNECTED -> {
                    val s = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    if (s != null) { battery = s.getIntExtra(BatteryManager.EXTRA_LEVEL, battery) }
                }
                "android.net.wifi.WIFI_AP_STATE_CHANGED" -> {
                    val st = i.getIntExtra("wifi_state", 0)
                    if (st == 13) setHotspot(true) else if (st == 11) setHotspot(false)
                }
                AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED -> toast(Evt("alarm", "Budilnik yangilandi", "Keyingisi: " + nextAlarm(), 3500))
            }
        }
    }

    private fun registerReceivers() {
        val f = IntentFilter()
        f.addAction(Intent.ACTION_BATTERY_CHANGED)
        f.addAction(Intent.ACTION_POWER_CONNECTED)
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
        f.addAction(AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_EXPORTED) else registerReceiver(rcv, f)
        if (sticky != null) handleBattery(sticky)
        pollHotspot()
    }

    // ---- AI (Siri kabi) ----
    private fun showAi(status: String, text: String, hold: Long) {
        setIcon(IconView.AI)
        ti.text = status
        rt.text = ""
        aiTx.text = text
        aiUntil = if (hold > 0) System.currentTimeMillis() + hold else 0
        if (mode != 4) setMode(4) else { setMode(4, false) }
    }

    private fun startAi() {
        if (prefs().getString("groq", "").isNullOrEmpty()) { toast(Evt("ai", "AI kaliti yo‘q", "Orol ilovasida kalitni kiriting", 4500)); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { toast(Evt("ai", "Mikrofon ruxsati kerak", "Orol ilovasida ruxsat bering", 4500)); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast(Evt("ai", "Ovoz aniqlash yo‘q", "Orol ilovasidagi matn maydonidan so‘rang", 5000)); return }
        showAi("Tinglayapman…", "", 0)
        try { rec?.destroy() } catch (e: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) aiTx.text = t
            }
            override fun onError(error: Int) { showAi("Eshitilmadi", "Qayta urinib ko‘ring", 3000) }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrEmpty()) showAi("Eshitilmadi", "Qayta urinib ko‘ring", 3000) else askAi(t)
            }
        })
        val it = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        it.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        it.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        it.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        try { r.startListening(it) } catch (e: Exception) { showAi("Xato", "Ovoz aniqlashni boshlab bo‘lmadi", 3000) }
    }

    private fun askAi(q: String) {
        showAi("O‘ylayapman…", q, 0)
        AiClient.ask(this, q) { a ->
            showAi("Orol AI", a, 14000)
            if (prefs().getBoolean("tts", false)) speak(a)
        }
    }

    private fun speak(t: String) {
        try {
            if (tts == null) {
                tts = TextToSpeech(this) { st ->
                    if (st == TextToSpeech.SUCCESS) { tts?.language = Locale.getDefault(); tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "orol") }
                }
            } else {
                tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "orol")
            }
        } catch (e: Exception) {}
    }
}
