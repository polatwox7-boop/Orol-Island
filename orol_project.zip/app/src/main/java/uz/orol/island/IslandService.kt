package uz.orol.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

class IslandService : Service() {
    companion object {
        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var pill: LinearLayout
    private lateinit var bg: GradientDrawable
    private lateinit var row: LinearLayout
    private lateinit var ic: TextView
    private lateinit var ti: TextView
    private lateinit var rt: TextView
    private lateinit var msg: TextView
    private lateinit var info: TextView
    private lateinit var ctrl: LinearLayout
    private lateinit var swBtn: TextView
    private lateinit var lp: WindowManager.LayoutParams

    private var attached = false
    private var mode = 0 // 0 idle, 1 compact, 2 toast, 3 expanded
    private var toastUntil = 0L
    private var toastPi: PendingIntent? = null
    private var swRun = false
    private var swStart = 0L
    private var swAcc = 0L
    private var tmRun = false
    private var tmEnd = 0L
    private var hotspot = false
    private var hotspotKnown = false
    private var plugged = false
    private var pluggedKnown = false
    private var battery = 0
    private var lowShown = false
    private var cutX = 0
    private var cutW = 0
    private var cutH = 0
    private var animator: ValueAnimator? = null
    private var tickCount = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun always() = getSharedPreferences("orol", MODE_PRIVATE).getBoolean("always", true)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        build()
        Bus.listener = { e -> ui.post { toast(e) } }
        registerReceivers()
        ui.post(tickRun)
    }

    override fun onDestroy() {
        running = false
        Bus.listener = null
        ui.removeCallbacksAndMessages(null)
        animator?.cancel()
        try { unregisterReceiver(rcv) } catch (e: Exception) {}
        if (attached) {
            try { wm.removeView(pill) } catch (e: Exception) {}
            attached = false
        }
        super.onDestroy()
    }

    private fun startAsForeground() {
        val ch = "orol"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Orol", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, ch)
            .setContentTitle("Orol ishlayapti")
            .setContentText("Kamera atrofidagi orol yoqilgan")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun tv(size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        t.includeFontPadding = false
        return t
    }

    private fun btn(label: String, act: () -> Unit): TextView {
        val b = tv(12.5f, Color.WHITE, true)
        b.text = label
        b.gravity = Gravity.CENTER
        b.setPadding(dp(8), dp(8), dp(8), dp(8))
        val g = GradientDrawable()
        g.setColor(0xFF2A2A2A.toInt())
        g.cornerRadius = dp(14).toFloat()
        b.background = g
        b.setOnClickListener { act() }
        return b
    }

    private fun build() {
        bg = GradientDrawable()
        bg.setColor(Color.BLACK)
        bg.cornerRadius = dp(18).toFloat()
        pill = LinearLayout(this)
        pill.orientation = LinearLayout.VERTICAL
        pill.background = bg
        pill.elevation = dp(6).toFloat()
        row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        ic = tv(16f)
        ti = tv(13f, Color.WHITE, true)
        ti.maxLines = 1
        ti.ellipsize = TextUtils.TruncateAt.END
        ti.setPadding(dp(8), 0, dp(8), 0)
        rt = tv(12f, 0xFFB0B0B0.toInt())
        row.addView(ic)
        row.addView(ti, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(rt)
        msg = tv(12.5f, 0xFFD0D0D0.toInt())
        msg.maxLines = 3
        msg.ellipsize = TextUtils.TruncateAt.END
        msg.setPadding(0, dp(6), 0, 0)
        info = tv(12f, 0xFF9A9A9A.toInt())
        info.setPadding(0, dp(8), 0, 0)
        ctrl = LinearLayout(this)
        ctrl.orientation = LinearLayout.HORIZONTAL
        ctrl.setPadding(0, dp(10), 0, 0)
        swBtn = btn("▶ Sekundomer") { toggleStopwatch() }
        val lpBtn = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) } }
        ctrl.addView(swBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f).apply { setMargins(dp(2), 0, dp(2), 0) })
        ctrl.addView(btn("Nol") { resetAll() }, lpBtn())
        ctrl.addView(btn("1m") { startTimer(60) }, lpBtn())
        ctrl.addView(btn("5m") { startTimer(300) }, lpBtn())
        ctrl.addView(btn("10m") { startTimer(600) }, lpBtn())
        pill.addView(row)
        pill.addView(msg)
        pill.addView(info)
        pill.addView(ctrl)
        pill.setOnClickListener { onPillClick() }

        readCutout()
        lp = WindowManager.LayoutParams(
            idleW(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.x = if (cutW > 0) cutX - screenW() / 2 else 0
        lp.y = if (cutW > 0) 0 else dp(4)
        try {
            wm.addView(pill, lp)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
        setMode(0, false)
    }

    private fun readCutout() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val dc = wm.currentWindowMetrics.windowInsets.displayCutout
                val r = dc?.boundingRects?.firstOrNull { it.top <= 2 }
                if (r != null) {
                    cutX = r.centerX()
                    cutW = r.width()
                    cutH = r.bottom
                }
            }
        } catch (e: Exception) {}
    }

    private fun idleW() = max(cutW + dp(20), dp(76))
    private fun idleH() = max(cutH + dp(6), dp(28))
    private fun compactW() = dp(180)
    private fun wideW() = min(screenW() - dp(24), dp(380))

    private fun animateWidth(to: Int) {
        animator?.cancel()
        if (!attached) return
        val a = ValueAnimator.ofInt(lp.width, to)
        a.duration = 300
        a.addUpdateListener {
            lp.width = it.animatedValue as Int
            try { wm.updateViewLayout(pill, lp) } catch (e: Exception) {}
        }
        animator = a
        a.start()
    }

    private fun setMode(m: Int, animate: Boolean = true) {
        mode = m
        val idle = m == 0
        pill.visibility = if (idle && !always()) View.GONE else View.VISIBLE
        pill.minimumHeight = if (idle) idleH() else 0
        pill.setPadding(if (idle) dp(8) else dp(14), if (idle) 0 else dp(8), if (idle) dp(8) else dp(14), if (idle) 0 else dp(8))
        row.visibility = if (idle) View.GONE else View.VISIBLE
        msg.visibility = if (m == 2 || m == 3) (if (msg.text.isNullOrEmpty()) View.GONE else View.VISIBLE) else View.GONE
        ctrl.visibility = if (m == 3) View.VISIBLE else View.GONE
        info.visibility = if (m == 3) View.VISIBLE else View.GONE
        bg.cornerRadius = dp(if (m == 3) 28 else if (m == 2) 24 else 18).toFloat()
        val w = when (m) { 0 -> idleW(); 1 -> compactW(); else -> wideW() }
        if (animate) animateWidth(w) else { lp.width = w; if (attached) try { wm.updateViewLayout(pill, lp) } catch (e: Exception) {} }
        refresh()
    }

    private fun toast(e: Evt) {
        ic.text = e.icon
        ti.text = e.title
        rt.text = ""
        msg.text = e.text
        toastPi = e.pi
        toastUntil = System.currentTimeMillis() + e.ms
        setMode(2)
    }

    private fun onPillClick() {
        if (mode == 2) {
            val p = toastPi
            if (p != null) {
                try { p.send() } catch (e: Exception) {}
                toastUntil = 0
                return
            }
        }
        if (mode == 3) setMode(if (swRun || tmRun) 1 else 0) else setMode(3)
    }

    private fun toggleStopwatch() {
        if (swRun) {
            swAcc += System.currentTimeMillis() - swStart
            swRun = false
        } else {
            swStart = System.currentTimeMillis()
            swRun = true
        }
        refresh()
    }

    private fun resetAll() {
        swRun = false
        swAcc = 0
        tmRun = false
        refresh()
    }

    private fun startTimer(sec: Int) {
        tmEnd = System.currentTimeMillis() + sec * 1000L
        tmRun = true
        refresh()
    }

    private fun elapsed() = swAcc + if (swRun) System.currentTimeMillis() - swStart else 0L

    private fun fmt(ms: Long): String {
        val t = max(0L, ms)
        val m = t / 60000
        val s = (t / 1000) % 60
        val d = (t / 100) % 10
        return String.format("%02d:%02d.%d", m, s, d)
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        if (tmRun && now >= tmEnd) {
            tmRun = false
            vibrate()
            toast(Evt("⏰", "Taymer tugadi", "", 5000))
            return
        }
        if (mode == 2 && now > toastUntil) {
            setMode(if (swRun || tmRun) 1 else 0)
            return
        }
        if (mode == 1 && !swRun && !tmRun) {
            setMode(0)
            return
        }
        if (mode == 1 || mode == 3) {
            if (tmRun) {
                ic.text = "⏳"
                ti.text = fmt(tmEnd - now)
                rt.text = "Taymer"
            } else if (swRun || swAcc > 0) {
                ic.text = "⏱"
                ti.text = fmt(elapsed())
                rt.text = "Sekundomer"
            } else {
                ic.text = "🏝"
                ti.text = "Orol"
                rt.text = ""
            }
        }
        if (mode == 3) {
            swBtn.text = if (swRun) "⏸ Sekundomer" else "▶ Sekundomer"
            val c = Calendar.getInstance()
            val hm = String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
            info.text = "🔋 $battery%" + (if (plugged) " ⚡ zaryadda" else "") + "   📶 Hotspot: " + (if (hotspot) "yoqiq" else "o‘chiq") + "   🕒 $hm"
        }
    }

    private val tickRun = object : Runnable {
        override fun run() {
            tickCount++
            refresh()
            if (tickCount % 40 == 0) pollHotspot()
            ui.postDelayed(this, if (swRun || tmRun || mode == 3) 100L else 500L)
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300, 150, 300), -1))
        } catch (e: Exception) {}
    }

    private fun setHotspot(on: Boolean) {
        val changed = hotspotKnown && on != hotspot
        hotspot = on
        hotspotKnown = true
        if (changed) toast(Evt("📶", if (on) "Hotspot yoqildi" else "Hotspot o‘chirildi", "", 3500))
    }

    private fun pollHotspot() {
        try {
            val wf = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val m = wf.javaClass.getDeclaredMethod("isWifiApEnabled")
            m.isAccessible = true
            setHotspot(m.invoke(wf) as Boolean)
        } catch (e: Throwable) {}
    }

    private fun handleBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        battery = if (level >= 0 && scale > 0) level * 100 / scale else battery
        val pl = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val changed = pluggedKnown && pl != plugged
        plugged = pl
        pluggedKnown = true
        if (changed) toast(Evt("⚡", if (pl) "Zaryad ulandi" else "Zaryad uzildi", "Batareya $battery%", 3500))
        if (!pl && battery in 1..15 && !lowShown) {
            lowShown = true
            toast(Evt("🪫", "Batareya kam", "$battery% qoldi", 4500))
        }
        if (battery > 20) lowShown = false
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> handleBattery(i)
                "android.net.wifi.WIFI_AP_STATE_CHANGED" -> {
                    val st = i.getIntExtra("wifi_state", 0)
                    if (st == 13) setHotspot(true) else if (st == 11) setHotspot(false)
                }
            }
        }
    }

    private fun registerReceivers() {
        val f = IntentFilter()
        f.addAction(Intent.ACTION_BATTERY_CHANGED)
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
        val sticky = if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_EXPORTED) else registerReceiver(rcv, f)
        if (sticky != null) handleBattery(sticky)
        pollHotspot()
    }
}
