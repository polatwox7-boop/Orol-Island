package uz.orol.island

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    fun ask(ctx: Context, prompt: String, cb: (String) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val r = try { call(app, prompt) } catch (e: Exception) { "AI xatosi: " + (e.message ?: "noma’lum") }
            Handler(Looper.getMainLooper()).post { cb(r) }
        }.start()
    }

    private fun call(ctx: Context, prompt: String): String {
        val sp = ctx.getSharedPreferences("orol", Context.MODE_PRIVATE)
        val key = sp.getString("groq", "") ?: ""
        if (key.isEmpty()) return "AI kaliti kiritilmagan"
        var model = sp.getString("model", "") ?: ""
        if (model.isEmpty()) {
            model = pickModel(key)
            sp.edit().putString("model", model).apply()
        }
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", "Sen Orol yordamchisan. O‘zbek tilida juda qisqa, 1-2 jumlada javob ber."))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", model).put("max_tokens", 200).put("temperature", 0.6).put("messages", msgs)
        val res = http("https://api.groq.com/openai/v1/chat/completions", "POST", key, body.toString())
        val j = JSONObject(res.second)
        if (res.first != 200) {
            sp.edit().remove("model").apply()
            throw Exception(j.optJSONObject("error")?.optString("message") ?: "HTTP ${res.first}")
        }
        return j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }

    private fun pickModel(key: String): String {
        try {
            val res = http("https://api.groq.com/openai/v1/models", "GET", key, null)
            val arr = JSONObject(res.second).getJSONArray("data")
            val ids = ArrayList<String>()
            for (i in 0 until arr.length()) ids.add(arr.getJSONObject(i).getString("id"))
            for (p in listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "openai/gpt-oss-20b")) if (ids.contains(p)) return p
            ids.firstOrNull { !it.contains("whisper") && !it.contains("guard") && !it.contains("tts") }?.let { return it }
        } catch (e: Exception) {}
        return "llama-3.3-70b-versatile"
    }

    private fun http(url: String, method: String, key: String, body: String?): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer $key")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val st = if (code in 200..299) c.inputStream else c.errorStream
        val txt = st?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, txt)
    }
}
