package uz.orol.island

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val important = n.category == Notification.CATEGORY_ALARM || n.category == Notification.CATEGORY_CALL
        if (!important) {
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        }
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val icon = try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        val acts = ArrayList<Pair<String, android.app.PendingIntent>>()
        if (important) {
            n.actions?.forEach { a ->
                val pi = a.actionIntent
                val t = a.title?.toString()
                if (pi != null && !t.isNullOrEmpty() && acts.size < 3) acts.add(Pair(t, pi))
            }
        }
        val head = if (important) (if (n.category == Notification.CATEGORY_ALARM) "⏰ " else "📞 ") else ""
        Bus.post(
            Evt(
                "🔔", head + (if (title.isEmpty()) label else "$label: $title"), text,
                if (important) 0 else 5000, n.contentIntent, icon, important, sbn.key, acts
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        Bus.remove(sbn.key)
    }
}
